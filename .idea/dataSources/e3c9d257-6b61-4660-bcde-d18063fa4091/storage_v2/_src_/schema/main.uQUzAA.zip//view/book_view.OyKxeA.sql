CREATE VIEW book_view as
select * from books;

